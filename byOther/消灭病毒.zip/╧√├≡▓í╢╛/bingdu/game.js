require("weapp-adapter.js");

window.md5 = require("./md5.min.js");

var mta = window.mta = require("mta_analysis.js");

require("./code.js");