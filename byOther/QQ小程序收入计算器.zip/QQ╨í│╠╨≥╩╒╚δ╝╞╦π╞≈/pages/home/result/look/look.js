Page({
    data: {
        objList: [ {
            sr: "0<税前收入<=800",
            gz: "不用交税"
        }, {
            sr: "800<税前收入<=4000",
            gz: "(税前收入-800)×20%=税费"
        }, {
            sr: "4000<税前收入<=20000",
            gz: "(税前收入×80%)x20%=税费"
        }, {
            sr: "20000<税前收入<=50000",
            gz: "(税前收入×80%)x30%=税费"
        }, {
            sr: "50000<税前收入",
            gz: "(税前收入×80%)x40%=税费"
        } ]
    },
    onLoad: function(t) {
        this.setData({
            startKm: startKm,
            startPrice: startPrice,
            outKmPrice: outKmPrice
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});