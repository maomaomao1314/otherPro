Page({
    data: {},
    onLoad: function(o) {
        var n = this, e = o.price;
        e <= 800 ? n.setData({
            price: e,
            ksPrice: 0,
            options: o
        }) : e > 800 && e <= 4e3 ? n.setData({
            zengzhishui:(e /1.03)*.03,
            fujiashui:(e /1.03)*.03*.06,
            geshui:(e-800-(e /1.03)*.03*.06 -(e /1.03)*.03 ) *.2,
            price: e - (e /1.03)*.03-(e /1.03)*.03*.06-(e-800-(e /1.03)*.03*.06 -(e /1.03)*.03 ) *.2,
            ksPrice: ((e /1.03)*.03)+((e /1.03)*.03*.06)+(e-800-(e /1.03)*.03*.06 -(e /1.03)*.03 ) *.2,
            options: o
        }) : e > 4e3 && e <= 2e4 ? n.setData({
            zengzhishui:(e /1.03)*.03,
            fujiashui:(e /1.03)*.03*.06,
            geshui:(e-(e /1.03)*.03*.06 -(e /1.03)*.03 )*.8*.2,
            price: e - (e /1.03)*.03-(e /1.03)*.03*.06-(e-(e /1.03)*.03*.06 -(e /1.03)*.03 )*.8*.2,
            ksPrice: ((e /1.03)*.03)+((e /1.03)*.03*.06)+((e-(e /1.03)*.03*.06 -(e /1.03)*.03 )*.8*.2),
            options: o
        }) : e > 2e4 && e <= 5e4 ? n.setData({
            zengzhishui:(e /1.03)*.03,
            fujiashui:(e /1.03)*.03*.06,
            geshui:(e-(e /1.03)*.03*.06 -(e /1.03)*.03 )*.8*.3-2000,
            price: e - (e /1.03)*.03-(e /1.03)*.03*.06- ((e-(e /1.03)*.03*.06 -(e /1.03)*.03 )*.8*.3-2000 ) ,
            ksPrice: ((e /1.03)*.03)+((e /1.03)*.03*.06)+((e-(e /1.03)*.03*.06 -(e /1.03)*.03 )*.8*.3-2000),
            options: o
        }) : e > 5e4 && n.setData({
            zengzhishui:(e /1.03)*.03,
            fujiashui:(e /1.03)*.03*.06,
            geshui:(e-(e /1.03)*.03*.06 -(e /1.03)*.03 )*.8*.4-7000,
            price: e - (e /1.03)*.03  -(e /1.03)*.03*.06  - ( (e-(e /1.03)*.03*.06 -(e /1.03)*.03 )*.8*.4-7000 ),
            ksPrice: ((e /1.03)*.03)+((e /1.03)*.03*.06)+((e-(e /1.03)*.03*.06 -(e /1.03)*.03 )*.8*.4-7000),
            options: o
        });
    },
    look: function() {
        wx.navigateTo({
            url: "look/look"
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});