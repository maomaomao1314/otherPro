Page({
    data: {},
    onLoad: function(n) {},
    formSubmit: function(n) {
        console.log(n);
        var o = n.detail.value.price;
        if ("" != o) if (0 != o) {
            var t = o.substring(0, 1), e = o.substring(1, 2), i = o.substring(2, 3), s = o.split(".").length - 1;
            console.log(s), "." == t || "." != e && 0 == t && "." != i || 1 != s && 0 != s ? wx.showToast({
                title: "收入格式不正确",
                icon: "none",
                duration: 2e3
            }) : wx.navigateTo({
                url: "result/result?price=" + o
            });
        } else wx.showToast({
            title: "收入不能为0",
            icon: "none",
            duration: 2e3
        }); else wx.showToast({
            title: "收入不能为空",
            icon: "none",
            duration: 2e3
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});